[5/5 points] Parsing of input files: Success on all tests
[5/5 points] Coding Style (i.e., well designed, clean, commented code): well
designed and commented
[10/10 points] Ability to cast a ray and display the spheres properly: Success
on the tests.
[5/10 points] Local illumination: partial success on tests.
Test images not idential to provided images.
[0/10 points] Shadows and Reflection : no success with the recursion.